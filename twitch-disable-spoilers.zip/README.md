This is my first firefox addon, please let me know if you enjoy it, or have a position available for a junior dev.
