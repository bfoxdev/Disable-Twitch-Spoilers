// .tw-progress-bar
// that got everything
// a div itself in the .tw-progress-bar array has a structure: attributes: aria-valuenow: nodeValue that
